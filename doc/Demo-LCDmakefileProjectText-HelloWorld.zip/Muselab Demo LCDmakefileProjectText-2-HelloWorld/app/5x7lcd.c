#include "debug.h"
#include "5x7lcd.h"
# include "font5x7.h"


/* 5x7 font example
// Font data stored in flash memory (CH32V203 for module LHS154KC-PG04 1.54 inch 240RGB*240DOTS)
// Standard ASCII 5x7 font for characters 0x20-0x7F (32-127)
static const uint8_t Font5x7[] __attribute__((section(".rodata"))) = {
    0x00,0x00,0x00,0x00,0x00, // 32 " "
    0x00,0x00,0x5F,0x00,0x00, // 33 "!"
   }
*/

#define SPI_HW
#define USE_HORIZONTAL 0
#define LCD_W 240
#define LCD_H 240
#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE           	 0x001F  
#define BRED             0XF81F
#define GRED 			       0XFFE0
#define GBLUE			       0X07FF
#define RED           	 0xF800
#define MAGENTA       	 0xF81F
#define GREEN         	 0x07E0
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#define BROWN 			     0XBC40 // Brown
#define BRRED 			     0XFC07 // Brownish red
#define GRAY  			     0X8430 // Gray
#define DARKBLUE      	 0X01CF	// Dark blue
#define LIGHTBLUE      	 0X7D7C	// Light blue
#define GRAYBLUE       	 0X5458 // Gray blue
#define LIGHTGREEN     	 0X841F // Light green
#define LGRAY 			     0XC618 // Light gray (PANEL), window background color
#define LGRAYBLUE        0XA651 // Light gray blue (middle layer color)
#define LBBLUE           0X2B12 // Light brownish blue (inverted color for selected items)

#define LCD_SCLK_Clr() GPIO_ResetBits(GPIOB,GPIO_Pin_13) // SCL=SCLK
#define LCD_SCLK_Set() GPIO_SetBits(GPIOB,GPIO_Pin_13)
#define LCD_MOSI_Clr() GPIO_ResetBits(GPIOB,GPIO_Pin_15) // SDA=MOSI
#define LCD_MOSI_Set() GPIO_SetBits(GPIOB,GPIO_Pin_15)
#define LCD_RES_Clr()  GPIO_ResetBits(GPIOB,GPIO_Pin_11) // RES
#define LCD_RES_Set()  GPIO_SetBits(GPIOB,GPIO_Pin_11)
#define LCD_DC_Clr()   GPIO_ResetBits(GPIOB,GPIO_Pin_10) // DC
#define LCD_DC_Set()   GPIO_SetBits(GPIOB,GPIO_Pin_10)
#define LCD_CS_Clr()   GPIO_ResetBits(GPIOB,GPIO_Pin_12) // CS
#define LCD_CS_Set()   GPIO_SetBits(GPIOB,GPIO_Pin_12)
#define LCD_BLK_Clr()  GPIO_ResetBits(GPIOB,GPIO_Pin_9)  // BLK
#define LCD_BLK_Set()  GPIO_SetBits(GPIOB,GPIO_Pin_9)

//============================== New Text Routines Start ====================================================
/**
 * @brief Draw a single character at specified position
 * @param x X coordinate (left edge)
 * @param y Y coordinate (top edge)
 * @param ascii_code ASCII character to draw
 * @param fg_color Foreground color (text color)
 * @param bg_color Background color
 * @param scale Scaling factor (1=5x7, 2=10x14, etc.)
 */
// Forward Function prototype Declarations
void LCD_DrawString(u16 x, u16 y, const char* str, u16 fg_color, u16 bg_color, u8 scale);
void LCD_DrawChar_Scale(u16 x, u16 y, u8 ascii_code, u16 fg_color, u16 bg_color, u8 scale);
void LCD_Address_Set(u16 x1, u16 y1, u16 x2, u16 y2);
void LCD_WR_DATA(u16 dat);
void LCD_Fill_Fast(u16 xsta, u16 ysta, u16 xend, u16 yend, u16 color);

/**
 * @brief Optimized version - draw character with scaling using fast SPI
 */
void LCD_DrawChar_Scale(u16 x, u16 y, u8 ascii_code, u16 fg_color, u16 bg_color, u8 scale)
{
  if (ascii_code < 0x20 || ascii_code > 0x7F) 
  {
    ascii_code = 0x20;
  }

  uint16_t offset = (ascii_code - 0x20) * 5;
  const uint8_t* font_ptr = &Font5x7[offset];

  // Calculate the full character size with scaling
  u8 char_width = 6 * scale;   // 5 pixels + 1 spacing, scaled
  u8 char_height = 7 * scale;  // 7 pixels high, scaled

  // Set address window for the entire scaled character (including spacing)
  LCD_Address_Set(x, y, x + char_width - 1, y + char_height - 1);
  LCD_CS_Clr();
  
  // Draw ROW by ROW (for LCD addressing)
  for (u8 row = 0; row < 7; row++) 
  {
    // Repeat each row 'scale' times for vertical scaling
    for (u8 s_row = 0; s_row < scale; s_row++) 
    {
      // Draw each column in this row
      for (u8 col = 0; col < 6; col++)        
      {
        u16 color;
        if (col < 5) 
        {
          // Read the column byte and check the bit for this row
          u8 column_data = font_ptr[col];
          color = (column_data & (1 << row)) ? fg_color : bg_color;
        }
        else 
        {
          // Last column is spacing
          color = bg_color;
        }
                
        // Repeat each pixel 'scale' times for horizontal scaling
        for (u8 s_col = 0; s_col < scale; s_col++) 
        {
          while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
          SPI_I2S_SendData(SPI2, color >> 8);
          while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
          SPI_I2S_SendData(SPI2, color);
        }
      }
    }
  }
  LCD_CS_Set();
}
void LCD_DrawChar_Fast(u16 x, u16 y, u8 ascii_code, u16 fg_color, u16 bg_color)
{
    if (ascii_code < 0x20 || ascii_code > 0x7F) 
    {
        ascii_code = 0x20;
    }
    
    uint16_t offset = (ascii_code - 0x20) * 5;
    const uint8_t* font_ptr = &Font5x7[offset];
    
    // Set address window for entire character (6x7 including spacing)
    // FIXED: Correct dimensions for 6 columns × 7 rows
    LCD_Address_Set(x, y, x + 5, y + 6);
    
    LCD_CS_Clr();
    
    // FIXED: Draw ROW by ROW (not column by column)
    // LCD address windows fill left-to-right, then top-to-bottom
    for (u8 row = 0; row < 7; row++) 
    {
        for (u8 col = 0; col < 6; col++) 
        {
            u8 column_data = (col < 5) ? font_ptr[col] : 0x00; // Last column is spacing
            u16 color = (column_data & (1 << row)) ? fg_color : bg_color;
            
            while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
            SPI_I2S_SendData(SPI2, color >> 8);
            while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
            SPI_I2S_SendData(SPI2, color);
        }
    }
    LCD_CS_Set();
}
/**
 * @brief Draw a string at specified position
 * @param x X coordinate (left edge)
 * @param y Y coordinate (top edge)
 * @param str Null-terminated string
 * @param fg_color Foreground color
 * @param bg_color Background color
 * @param scale Scaling factor
 */
void LCD_DrawString(u16 x, u16 y, const char* str, u16 fg_color, u16 bg_color, u8 scale)
{
    u16 x_offset = 0;
    while(*str) 
    {
        LCD_DrawChar_Scale(x + x_offset, y, *str, fg_color, bg_color, scale);
        x_offset += 6 * scale; // Move right by 5 pixels + 1 spacing
        str++;
    }
}
//============================ End Characters ======================================================
void LCD_Writ_Bus(u8 dat) 
{
#if defined(SPI_GPIO)
	u8 i;
	LCD_CS_Clr();
	for(i=0;i<8;i++)
	{			  
		LCD_SCLK_Clr();
		if(dat&0x80)
		{
		   LCD_MOSI_Set();
		}
		else
		{
		   LCD_MOSI_Clr();
		}
		LCD_SCLK_Set();
		dat<<=1;
	}	
  LCD_CS_Set();	
#elif defined(SPI_HW)
	LCD_CS_Clr();
  while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
	SPI_I2S_SendData(SPI2,dat);
  Delay_Us(100);
	LCD_CS_Set();
#endif
}
void LCD_WR_DATA8(u8 dat)
{
	LCD_Writ_Bus(dat);
}
void LCD_WR_DATA(u16 dat)
{
	LCD_Writ_Bus(dat>>8);
	LCD_Writ_Bus(dat);
}
void LCD_WR_REG(u8 dat)
{
	LCD_DC_Clr();
	LCD_Writ_Bus(dat);
	LCD_DC_Set();
}
void LCD_Address_Set(u16 x1,u16 y1,u16 x2,u16 y2)
{
	if(USE_HORIZONTAL==0)
	{
		LCD_WR_REG(0x2a);// Column address set
		LCD_WR_DATA(x1);
		LCD_WR_DATA(x2);
		LCD_WR_REG(0x2b);// Row address set
		LCD_WR_DATA(y1);
		LCD_WR_DATA(y2);
		LCD_WR_REG(0x2c);// Memory write
	}
	else if(USE_HORIZONTAL==1)
	{
		LCD_WR_REG(0x2a);// Column address set
		LCD_WR_DATA(x1);
		LCD_WR_DATA(x2);
		LCD_WR_REG(0x2b);// Row address set
		LCD_WR_DATA(y1+80);
		LCD_WR_DATA(y2+80);
		LCD_WR_REG(0x2c);// Memory write
	}
	else if(USE_HORIZONTAL==2)
	{
		LCD_WR_REG(0x2a);// Column address set
		LCD_WR_DATA(x1);
		LCD_WR_DATA(x2);
		LCD_WR_REG(0x2b);// Row address set
		LCD_WR_DATA(y1);
		LCD_WR_DATA(y2);
		LCD_WR_REG(0x2c);// Memory write
	}
	else
	{
		LCD_WR_REG(0x2a);// Column address set
		LCD_WR_DATA(x1+80);
		LCD_WR_DATA(x2+80);
		LCD_WR_REG(0x2b);// Row address set
		LCD_WR_DATA(y1);
		LCD_WR_DATA(y2);
		LCD_WR_REG(0x2c);// Memory write
	}
}
int lcd_gpio_init()
{
#if defined(SPI_GPIO)
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

#elif defined(SPI_HW)
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    SPI_InitTypeDef  SPI_InitStructure = {0};
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
    /* DC (PB10) & RESET (PB11) & CS (PB12) */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //GPIO_SetBits(GPIOA, GPIO_Pin_2);
    /* SPI_CLK */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    /* SPI_MISO */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    /* SPI_MOSI */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4; /* APB1_CLK (72MHz) */
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI2, &SPI_InitStructure);
    SPI_Cmd(SPI2, ENABLE);
#endif
  return 0;
}
void LCD_Fill_Slow(u16 xsta,u16 ysta,u16 xend,u16 yend,u16 color)
{
	u16 i,j;
	LCD_Address_Set(xsta,ysta,xend-1,yend-1);// Set display range
	for(i=ysta;i<yend;i++)
	{
		for(j=xsta;j<xend;j++)
		{
			LCD_WR_DATA(color);
		}
	}
}
void LCD_Fill_Fast(u16 xsta,u16 ysta,u16 xend,u16 yend,u16 color)
{
 u16 i,j;
 LCD_Address_Set(xsta,ysta,xend-1,yend-1);// Set display range
 LCD_CS_Clr();
 for(i=ysta;i<yend;i++)
 {
   for(j=xsta;j<xend;j++)
   {
      while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
      SPI_I2S_SendData(SPI2,color >> 8);
      while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
      SPI_I2S_SendData(SPI2,color);
   }
  }
 LCD_CS_Set();
}
void LCD_ShowPicture_Slow(u16 x,u16 y,u16 length,u16 width,const u8 pic[])
{
	u16 i,j;
	u32 k=0;
	LCD_Address_Set(x,y,x+length-1,y+width-1);
	for(i=0;i<length;i++)
	{
		for(j=0;j<width;j++)
		{
			LCD_WR_DATA8(pic[k*2]);
			LCD_WR_DATA8(pic[k*2+1]);
			k++;
		}
	}
}
void LCD_ShowPicture_Fast(u16 x,u16 y,u16 length,u16 width,const u8 pic[])
{
	u16 i,j;
	u32 k=0;
	LCD_Address_Set(x,y,x+length-1,y+width-1);

	LCD_CS_Clr();

	for(i=0;i<length;i++)
	{
		for(j=0;j<width;j++)
		{
			//LCD_WR_DATA8(pic[k*2]);
			//LCD_WR_DATA8(pic[k*2+1]);
      while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
      SPI_I2S_SendData(SPI2,pic[k*2]);
      //Delay_Us(100);
      while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET);
      SPI_I2S_SendData(SPI2,pic[k*2+1]);
			k++;
		}
	}
	LCD_CS_Set();
}
int lcd_init()
{
	lcd_gpio_init();
	//LCD_RES_Clr();// Reset LCD
	Delay_Ms(100);
	LCD_RES_Set();
	Delay_Ms(100);
	LCD_BLK_Set();// Turn on Backlight
  Delay_Ms(100);
      // ************* Start Initial Sequence ********** //
    LCD_WR_REG(0x11); // Sleep out 
    Delay_Ms(120); // Delay 120ms 
    // ************* Turn on Display ********** //
    LCD_WR_REG(0x21);  // Display inversion on
    LCD_WR_REG(0x29);  // Display on
    Delay_Ms(100);
    // ************* Start Initial Sequence ********** // 
    LCD_WR_REG(0x36);
    if (USE_HORIZONTAL == 0) LCD_WR_DATA8(0x00);
    else if (USE_HORIZONTAL == 1) LCD_WR_DATA8(0xC0);
    else if (USE_HORIZONTAL == 2) LCD_WR_DATA8(0x70);
    else LCD_WR_DATA8(0xA0);
    LCD_WR_REG(0x3A);            
    LCD_WR_DATA8(0x05);
    LCD_WR_REG(0xB2);            
    LCD_WR_DATA8(0x0C);
    LCD_WR_DATA8(0x0C); 
    LCD_WR_DATA8(0x00); 
    LCD_WR_DATA8(0x33); 
    LCD_WR_DATA8(0x33);            
    LCD_WR_REG(0xB7);            
    LCD_WR_DATA8(0x35);
    LCD_WR_REG(0xBB);            
    LCD_WR_DATA8(0x32); // Vcom = 1.35V
    LCD_WR_REG(0xC2);
    LCD_WR_DATA8(0x01);
    LCD_WR_REG(0xC3);            
    LCD_WR_DATA8(0x15); // GVDD = 4.8V, related to power supply voltage
    LCD_WR_REG(0xC4);            
    LCD_WR_DATA8(0x20); // VDV, 0x20: 0V
    LCD_WR_REG(0xC6);            
    LCD_WR_DATA8(0x0F); // 0x0F: 60Hz        
    Delay_Ms(100);
    // Fill screen with black background
    LCD_Fill_Fast(0, 0, LCD_W, LCD_H, BLACK);
  return 0;
}

