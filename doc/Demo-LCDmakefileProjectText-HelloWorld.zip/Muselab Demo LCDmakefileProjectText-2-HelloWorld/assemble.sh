echo "Clean ALL and assemble"
make clean
make -j8

