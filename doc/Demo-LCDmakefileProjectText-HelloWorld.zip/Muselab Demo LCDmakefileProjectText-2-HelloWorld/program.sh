# As root, run sudo sh program.sh
echo "Put into program mode first, Press RST and Hold down, Press BOOT, Release RST, then Release BOOT!"
make clean
make -j8
make burnw

